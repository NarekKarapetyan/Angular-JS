'use strict';
angular.module('confusionApp', []);
