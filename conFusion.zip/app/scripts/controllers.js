'use strict';
angular.module('confusionApp')

.controller('MenuController', ['$scope', 'menuFactory', function($scope, menuFactory) {
                        $scope.tab = 1;
            $scope.filtText = '';
             $scope.dishes= menuFactory.getDishes();


                         $scope.showDetails = false;
                         $scope.toggleDetails = function() {
                $scope.showDetails = !$scope.showDetails;
            };
             $scope.select = function(setTab) {
                $scope.tab = setTab;
                if (setTab === 2) {$scope
                    $scope.filtText = "appetizer";
                }
                else if (setTab === 3) {
                    $scope.filtText = "mains";
                }
                else if (setTab === 4) {
                    $scope.filtText = "dessert";
                }
                else {
                    $scope.filtText = "";
                }
            };
            $scope.isSelected = function (checkTab) {
                return ($scope.tab === checkTab);
            };
        }])
        /*.controller('ContactController', ['$scope', function($scope) {
            $scope.feedback = {mychannel:"", firstName:"", lastName:"", agree:false, email:"" };
                                   var channels = [{value:"tel", label:"Tel."}, {value:"Email",label:"Email"}];
                                   $scope.channels = channels;
                       $scope.invalidChannelSelection = false;
        }]) */

        /*.controller('FeedbackController', ['$scope', function($scope) {
                       $scope.sendFeedback = function() {
                               console.log($scope.feedback);
                               if ($scope.feedback.agree && ($scope.feedback.mychannel == "")&& !$scope.feedback.mychannel) {
                                   $scope.invalidChannelSelection = true;
                                                 console.log('incorrect');
                                             }
                                             else {
                                                 $scope.invalidChannelSelection = false;
                                                 $scope.feedback = {mychannel:"", firstName:"", lastName:"",
                                                                    agree:false, email:"" };
                                                 $scope.feedback.mychannel="";

                                                 $scope.feedbackForm.$setPristine();
                                                 console.log($scope.feedback);
                                             }
                                         };
                                     }]); */

.controller('DishDetailController', ['$scope', 'menuFactory', function($scope, menuFactory) {

var dish = menuFactory.getDish(3);
$scope.dish = dish;

}])
.controller('DishCommentController', ['$scope', function($scope) {

//Step 1: Create a JavaScript object to hold the comment from the form
$scope.currentobject = {
    rating:"",
    comment:"",
    author: "",
    date:""
}

var shownewcomment = false;
$scope.shownewcomment = shownewcomment;

$scope.submitComment = function () {
    $scope.shownewcomment = false;
    $scope.newobject = {};

    var curobj = $scope.currentobject;
    if(curobj.author!="" && curobj.comment!="" && curobj.rating!=""){
        $scope.currentobject.date = new Date().toISOString();
        $scope.newobject.rating = $scope.currentobject.rating;
        $scope.newobject.date = $scope.currentobject.date;
        $scope.newobject.comment = $scope.currentobject.comment;
        $scope.newobject.author = $scope.currentobject.author;
        $scope.dish.comments.push($scope.newobject);
    }

    console.log($scope.comments);
    $scope.commentForm.$setPristine();


    for(var key in $scope.currentobject){
        if ($scope.currentobject.hasOwnProperty(key)){
            $scope.currentobject[key] = "";
                }
        }
    }
    //Step 5: reset your JavaScript object that holds your comment

}])
